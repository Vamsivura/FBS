package com.vamsi.entities.customers;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "customer_credentials")
public class CustomerCredentials {
	private String user_type;
	@Id
	// @GeneratedValue(strategy = GenerationType.AUTO)
	private Integer customer_id;
	private String password;
	// private String login_status;

	public CustomerCredentials() {

	}

	public CustomerCredentials(String user_type, Integer customer_id, String password) {
		super();
		this.user_type = user_type;
		this.customer_id = customer_id;
		this.password = password;
	}

	public String getUser_type() {
		return user_type;
	}

	public void setUser_type(String user_type) {
		this.user_type = user_type;
	}

	public Integer getCustomer_id() {
		return customer_id;
	}

	public void setCustomer_id(Integer customer_id) {
		this.customer_id = customer_id;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	@Override
	public String toString() {
		return "CustomerCredentials [user_type=" + user_type + ", customer_id=" + customer_id + ", password=" + password
				+ "]";
	}
}
