package com.vamsi.entities.backend;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "geo_location")
public class GeoLocation {
	@Id
	private String city_code;
	private String state;
	private String city;
	private Double latitude;
	private Double longitude;

	public GeoLocation() {
	}

	public GeoLocation(String city_code, String state, String city, Double latitude, Double longitude) {
		this.city_code = city_code;
		this.state = state;
		this.city = city;
		this.latitude = latitude;
		this.longitude = longitude;
	}

	public String getCity_code() {
		return city_code;
	}

	public void setCity_code(String city_code) {
		this.city_code = city_code;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public Double getLatitude() {
		return latitude;
	}

	public void setLatitude(Double latitude) {
		this.latitude = latitude;
	}

	public Double getLongitude() {
		return longitude;
	}

	public void setLongitude(Double longitude) {
		this.longitude = longitude;
	}

	@Override
	public String toString() {
		return "GeoLocation [city_code=" + city_code + ", state=" + state + ", city=" + city + ", latitude=" + latitude
				+ ", longitude=" + longitude + "]";
	}

}
