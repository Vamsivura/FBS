package com.vamsi.entities.backend;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class Route {
	@Id
	private Integer route_Id;
	private String source;
	private String destination;
	private Integer distance;
	private String duration;
	private Integer km_cost;

	public Route() {
	}

	public Route(Integer route_Id, String source, String destination, Integer distance, String duration,
			Integer km_cost) {
		this.route_Id = route_Id;
		this.source = source;
		this.destination = destination;
		this.distance = distance;
		this.duration = duration;
		this.km_cost = km_cost;
	}

	public Integer getRoute_Id() {
		return route_Id;
	}

	public void setRoute_Id(Integer route_Id) {
		this.route_Id = route_Id;
	}

	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}

	public String getDestination() {
		return destination;
	}

	public void setDestination(String destination) {
		this.destination = destination;
	}

	public Integer getDistance() {
		return distance;
	}

	public void setDistance(Integer distance) {
		this.distance = distance;
	}

	public String getDuration() {
		return duration;
	}

	public void setDuration(String duration) {
		this.duration = duration;
	}

	public Integer getKm_cost() {
		return km_cost;
	}

	public void setKm_cost(Integer km_cost) {
		this.km_cost = km_cost;
	}

	@Override
	public String toString() {
		return "Route [route_Id=" + route_Id + ", source=" + source + ", destination=" + destination + ", distance="
				+ distance + ", duration=" + duration + ", km_cost=" + km_cost + "]";
	}

}
