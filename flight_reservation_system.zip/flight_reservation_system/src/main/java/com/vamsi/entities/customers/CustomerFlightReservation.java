package com.vamsi.entities.customers;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "flight_reservation")
public class CustomerFlightReservation {
	private Integer user_id;
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer pnr;
	private String source;
	private String destination;
	private String departureDate;
	private Integer seats;
	private String reservationType;

	public CustomerFlightReservation() {
	}

	public CustomerFlightReservation(Integer user_id, String source, String destination, String departureDate,
			Integer seats, String reservationType) {
		super();
		this.user_id = user_id;
		// this.pnr = pnr;
		this.source = source;
		this.destination = destination;
		this.departureDate = departureDate;
		this.seats = seats;
		this.reservationType = reservationType;
	}

	public Integer getUser_id() {
		return user_id;
	}

	public void setUser_id(Integer user_id) {
		this.user_id = user_id;
	}

	public Integer getPnr() {
		return pnr;
	}

	public void setPnr(Integer pnr) {
		this.pnr = pnr;
	}

	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}

	public String getDestination() {
		return destination;
	}

	public void setDestination(String destination) {
		this.destination = destination;
	}

	public String getDepartureDate() {
		return departureDate;
	}

	public void setDepartureDate(String departureDate) {
		this.departureDate = departureDate;
	}

	public Integer getSeats() {
		return seats;
	}

	public void setSeats(Integer seats) {
		this.seats = seats;
	}

	public String getReservationType() {
		return reservationType;
	}

	public void setReservationType(String reservationType) {
		this.reservationType = reservationType;
	}

	@Override
	public String toString() {
		return "CustomerFlightReservation [user_id=" + user_id + ", pnr=" + pnr + ", source=" + source
				+ ", destination=" + destination + ", departureDate=" + departureDate + ", seats=" + seats
				+ ", reservationType=" + reservationType + "]";
	}

}
