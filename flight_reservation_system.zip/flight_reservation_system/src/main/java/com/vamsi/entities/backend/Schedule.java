package com.vamsi.entities.backend;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class Schedule {
	@Id
	private Integer schedule_Id;
	private String flight_name;
	private String source;
	private String destination;
	private String departureDate;
	private String departureTime;

	public Schedule() {
	}

	
	
	

	public Schedule(Integer schedule_Id, String flight_name, String source, String destination, String departureDate,
			String departureTime) {
		super();
		this.schedule_Id = schedule_Id;
		this.flight_name = flight_name;
		this.source = source;
		this.destination = destination;
		this.departureDate = departureDate;
		this.departureTime = departureTime;
	}

	public Integer getSchedule_Id() {
		return schedule_Id;
	}

	public void setSchedule_Id(Integer schedule_Id) {
		this.schedule_Id = schedule_Id;
	}

	public String getFlight_name() {
		return flight_name;
	}

	public void setFlight_name(String flight_name) {
		this.flight_name = flight_name;
	}

	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}

	public String getDestination() {
		return destination;
	}

	public void setDestination(String destination) {
		this.destination = destination;
	}


	public String getDepartureDate() {
		return departureDate;
	}

	public void setDepartureDate(String departureDate) {
		this.departureDate = departureDate;
	}

	public String getDepartureTime() {
		return departureTime;
	}

	public void setDepartureTime(String departureTime) {
		this.departureTime = departureTime;
	}





	@Override
	public String toString() {
		return "Schedule [schedule_Id=" + schedule_Id + ", flight_name=" + flight_name + ", source=" + source
				+ ", destination=" + destination + ", departureDate=" + departureDate + ", departureTime="
				+ departureTime + "]";
	}





	
}
