package com.vamsi.entities.backend;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class Flight {

	@Id
	private String flight_name;
	private Integer total_seats;
	private Integer economy_seats;
	private Integer business_seats;
	private Integer economy_seat_fare;
	private Integer business_seat_fare;

	public Flight() {
	}

	public Flight(String flight_name, Integer total_seats, Integer economy_seats,
			Integer business_seats, Integer economy_seat_fare, Integer business_seat_fare) {
		this.flight_name = flight_name;
		this.total_seats = total_seats;
		this.economy_seats = economy_seats;
		this.business_seats = business_seats;
		this.economy_seat_fare = economy_seat_fare;
		this.business_seat_fare = business_seat_fare;
	}


	public String getFlight_name() {
		return flight_name;
	}

	public void setFlight_name(String flight_name) {
		this.flight_name = flight_name;
	}

	public Integer getTotal_seats() {
		return total_seats;
	}

	public void setTotal_seats(Integer total_seats) {
		this.total_seats = total_seats;
	}

	public Integer getEconomy_seats() {
		return economy_seats;
	}

	public void setEconomy_seats(Integer economy_seats) {
		this.economy_seats = economy_seats;
	}

	public Integer getBusiness_seats() {
		return business_seats;
	}

	public void setBusiness_seats(Integer business_seats) {
		this.business_seats = business_seats;
	}

	public Integer getEconomy_seat_fare() {
		return economy_seat_fare;
	}

	public void setEconomy_seat_fare(Integer economy_seat_fare) {
		this.economy_seat_fare = economy_seat_fare;
	}

	public Integer getBusiness_seat_fare() {
		return business_seat_fare;
	}

	public void setBusiness_seat_fare(Integer business_seat_fare) {
		this.business_seat_fare = business_seat_fare;
	}

	@Override
	public String toString() {
		return "flight_name=" + flight_name + ", total_seats=" + total_seats
				+ ", economy_seats=" + economy_seats + ", business_seats=" + business_seats + ", economy_seat_fare="
				+ economy_seat_fare + ", business_seat_fare=" + business_seat_fare + "]";
	}
}
