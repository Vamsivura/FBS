package com.vamsi.backenddata;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.vamsi.entities.backend.Route;
import com.vamsi.repository.RouteRepository;

@Controller
public class RouteDataBase {

		@Autowired
		RouteRepository routeRepo;

		@GetMapping("/routeData")
		@ResponseBody
		public String RouteDataInsertion() {
			Route route = new Route(1,"JFK","SFO", 868, "1:07",5);
			routeRepo.save(route);
			route = new Route(2,"JFK","AUS", 1508, "1:88",5);
			routeRepo.save(route);
			route = new Route(3,"SFO","JFK", 996, "1.24",5);
			routeRepo.save(route);
			route = new Route(4,"SEA","BOS", 1561, "1.95",5);
			routeRepo.save(route);
			route = new Route(5,"BOS","SEA", 1818, "2.27",5);
			routeRepo.save(route);
			route = new Route(6,"ORD","AUS", 2261, "2.82",5);
			routeRepo.save(route);
			return "data inserted Sucessfully";
		}
			
}
