package com.vamsi.backenddata;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.vamsi.entities.backend.GeoLocation;
import com.vamsi.repository.GeoLocationRepository;

@Controller
public class GeoLocationDataBase {
	@Autowired
	GeoLocationRepository geoLocationRepo;

	@GetMapping("/GeoData")
	@ResponseBody
	public String GeoDataInsertion(	) {
		
		GeoLocation data=new GeoLocation("ORD", "O Hare International Airport", "USA", 11.6234,92.7265);		
		geoLocationRepo.save(data);
		data=new GeoLocation("BOS", "Boston Logan International Airport", "USA", 17.6868,83.2185);		
		geoLocationRepo.save(data);
		data=new GeoLocation("JFK", "John F Kennedy International Airport ", "Newyork", 26.1158,91.7086);		
		geoLocationRepo.save(data);
		data=new GeoLocation ("SFO", "San Francisco International Airport", "USA", 25.5941,85.1376);
		geoLocationRepo.save(data);
		data=new GeoLocation ("SEA", "Seattle Tacoma International Airport", "USA", 28.6139,77.2090);
		geoLocationRepo.save(data);
		data=new GeoLocation ("AUS", "Austin Bergstrom International Airport", "USA", 15.2993,74.1240);
		geoLocationRepo.save(data);
		
		
		
		return "Geo Location Data Inserted Successfully";
		
		

		/*@RequestParam("city_code") String city_code,
		@RequestParam("state") String state,
		@RequestParam("city") String city,
		@RequestParam("latitude") Double latitude,
		@RequestParam("longitude") Double longitude*/
	}

}
