package com.vamsi.backenddata;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.vamsi.entities.backend.Schedule;
import com.vamsi.repository.ScheduleRepository;

@Controller
public class ScheduleDataBase {

	@Autowired
	ScheduleRepository scheduleRepo;

	@GetMapping("/ScheduleData")
	@ResponseBody
	public String ScheduleDataInsertion() {
		Schedule schedule = new Schedule(1, "Alaska", "JFK", "SFO", "20-MAR-2023", "09:00");
		scheduleRepo.save(schedule);
		schedule = new Schedule(2, "Delta", "AUS", "BOS", "20-MAR-2023", "12:00");
		scheduleRepo.save(schedule);
		schedule = new Schedule(3, "American", "SEA", "AUS", "20-MAR-2023", "15:00");
		scheduleRepo.save(schedule);
		schedule = new Schedule(4, "JetBlue", "ORD", "AUS", "20-MAR-2023", "20:00");
		scheduleRepo.save(schedule);
		schedule = new Schedule(5, "Alaska", "SFO", "JFK", "20-MAR-2023", "11:00");
		scheduleRepo.save(schedule);
		schedule = new Schedule(6, "American", "AUS", "BOS", "20-MAR-2023", "14:00");
		scheduleRepo.save(schedule);
		schedule = new Schedule(7, "Delta", "ORD", "JFK", "21-MAR-2023", "09:00");
		scheduleRepo.save(schedule);
		schedule = new Schedule(8, "JetBlue", "BOS", "SFO", "20-MAR-2023", "09:00");
		scheduleRepo.save(schedule);
		
		return "Schedule Data Inserted Sucessfully";
	}
}