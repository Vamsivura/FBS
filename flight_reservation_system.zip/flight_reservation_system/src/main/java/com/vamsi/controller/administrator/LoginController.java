package com.vamsi.controller.administrator;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.vamsi.entities.administrator.AdministratorCredentials;
import com.vamsi.entities.customers.CustomerCredentials;
import com.vamsi.repository.AdministratorCredentialsRepository;
import com.vamsi.repository.CustomerCredentialsRepository;

@Controller
public class LoginController {

	@Autowired
	CustomerCredentialsRepository cCredentialsRepo;

	@Autowired
	AdministratorCredentialsRepository aCredentialsRepo;

	@GetMapping(path = "/login")
	public String customerAuthentication(@RequestParam("userType") String userType, @RequestParam("userId") Integer id,
			@RequestParam("password") String password) {
		Boolean flag = false;
		if (userType.equals("customer")) {
			ArrayList<CustomerCredentials> cList = (ArrayList<CustomerCredentials>) cCredentialsRepo.findAll();
			for (CustomerCredentials c : cList) {
				if (c.getCustomer_id().equals(id) && c.getPassword().equals(password)) {
					flag = true;
					break;
				} else
					flag = false;
			}
			if (flag)
				return "customerLogin";
			else
				return "loginFail";
		} else {
			ArrayList<AdministratorCredentials> aList = (ArrayList<AdministratorCredentials>) aCredentialsRepo
					.findAll();
			for (AdministratorCredentials a : aList) {
				if (a.getAdministrator_id().equals(id) && a.getPassword().equals(password)) {
					flag = true;
					break;
				} else
					flag = false;
			}
			if (flag)
				return "administratorLogin";
			else
				return "loginFail";
		}
	}
	@GetMapping(path = "/forgotPassword")
	public String changePassword(@RequestParam("userType") String userType, @RequestParam("userId") Integer id,
			@RequestParam("password") String password) {
		if (userType.equals("customer")) {
			CustomerCredentials customerCred = new CustomerCredentials(userType,id, password);
			cCredentialsRepo.save(customerCred);
			return "passwordChanged";
		}else {
			AdministratorCredentials adminCred = new AdministratorCredentials(userType,id, password);
			aCredentialsRepo.save(adminCred);
			return "passwordChanged";
		
		}
	}
		
}
