package com.vamsi.controller.customer;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.vamsi.entities.customers.CustomerCredentials;
import com.vamsi.entities.customers.CustomerProfile;
import com.vamsi.repository.CustomerCredentialsRepository;
import com.vamsi.repository.CustomerProfileRepository;

@Controller
public class CustomerController {
	@Autowired
	CustomerProfileRepository cProfileRepo;

	@Autowired
	CustomerCredentialsRepository cCredentialsRepo;

	@GetMapping(path = "/customer")
	public String customerRegister(@RequestParam("userId") Integer id, @RequestParam("email") String emailId,
			@RequestParam("firstName") String firstName, @RequestParam("lastName") String lastName,
			@RequestParam("dob") String DOB, @RequestParam("age") Integer age, @RequestParam("gender") String gender,
			@RequestParam("address") String address, @RequestParam("phoneNumber") Long phoneNumber,
			@RequestParam("password") String password) {

		CustomerProfile customerPro = new CustomerProfile(id, firstName, lastName, DOB, age, gender, address,
				phoneNumber, emailId);
		CustomerCredentials customerCred = new CustomerCredentials("customer",id, password);
		// save customer details
		cProfileRepo.save(customerPro);
		cCredentialsRepo.save(customerCred);
		return "loginSuccess";
	}

	@RequestMapping(path = "/customer/all", method = RequestMethod.GET)
	@ResponseBody
	public ArrayList<CustomerProfile> getAllCustomers() {
		return (ArrayList<CustomerProfile>) cProfileRepo.findAll();
	}

	@RequestMapping(path = "/customerCredentials/all", method = RequestMethod.GET)
	@ResponseBody
	public ArrayList<CustomerCredentials> getAllCustomerCredentials() {
		return (ArrayList<CustomerCredentials>) cCredentialsRepo.findAll();
	}
}
