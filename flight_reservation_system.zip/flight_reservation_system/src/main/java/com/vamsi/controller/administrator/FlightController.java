package com.vamsi.controller.administrator;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.vamsi.entities.backend.Flight;
import com.vamsi.repository.FlightRepository;

@Controller
public class FlightController {
	
	//Flight CRUD
	@Autowired
	FlightRepository flightRepo;
	
	//Add & Modify
	@GetMapping(path="/insertFlight")
	public String insertFlight(@RequestParam("flight_name") String flight_name,
			@RequestParam("total_seats") Integer total_seats,
			@RequestParam("economy_seats") Integer economy_seats,
			@RequestParam("business_seats") Integer business_seats,
			@RequestParam("economy_seat_fare") Integer economy_seat_fare,
			@RequestParam("business_seat_fare") Integer business_seat_fare
			) {
		
		Flight flight=new Flight(flight_name,total_seats,economy_seats,business_seats,economy_seat_fare,business_seat_fare);
		flightRepo.save(flight);	
		return "success";
	}

	//view
	@GetMapping("/viewAllFlights")
	public String viewEmployees(Model model) {
		List<Flight> f = (ArrayList<Flight>) flightRepo.findAll();
		model.addAttribute("flights", f);
		return "allFlights";
	}
	
	//delete
	@GetMapping(path = "/deleteFlight")
	public String deleteFlight(@RequestParam("flight_name") String flight_name) {
		flightRepo.deleteById(flight_name);
		return "success";
	}
}
