package com.vamsi.controller.customer;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.vamsi.entities.backend.GeoLocation;
import com.vamsi.entities.backend.Schedule;
import com.vamsi.entities.customers.PassengerDetails;
import com.vamsi.repository.CustomerFlightRepository;
import com.vamsi.repository.GeoLocationRepository;
import com.vamsi.repository.PassengerDetailsRepository;
import com.vamsi.repository.ScheduleRepository;

@Controller
public class TicketController {

    @Autowired
    CustomerFlightRepository repo;

    @Autowired
    PassengerDetailsRepository passRepo;

    @Autowired
    GeoLocationRepository geoLocationRepo;

    @Autowired
    ScheduleRepository scheduleRepo;

    @GetMapping("/ticketReservation")
    public String reservation(@RequestParam("firstName") String firstName, @RequestParam("lastName") String lastName,
            @RequestParam("journey_date") String journey_date, @RequestParam("source") String source,
            @RequestParam("destination") String destination, @RequestParam("seat_type") String seat_type,
            @RequestParam("seats") Integer seats, @RequestParam("payment_mode") String payment_mode, Model model) {
        System.out.println("Ticket booking");

        double AVERAGE_RADIUS_OF_EARTH_KM = 6371;
        GeoLocation sc = geoLocationRepo.findById(source).get();
        GeoLocation dest = geoLocationRepo.findById(destination).get();

        double userLat = sc.getLatitude();
        double userLng = sc.getLongitude();
        double venueLat = dest.getLatitude();
        double venueLng = dest.getLongitude();
        double latDistance = Math.toRadians(userLat - venueLat);
        double lngDistance = Math.toRadians(userLng - venueLng);
        double a = Math.sin(latDistance / 2) * Math.sin(latDistance / 2) + Math.cos(Math.toRadians(userLat))
                * Math.cos(Math.toRadians(venueLat)) * Math.sin(lngDistance / 2) * Math.sin(lngDistance / 2);

        double c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
        double distance = (Math.round(AVERAGE_RADIUS_OF_EARTH_KM * c));

        String seatType = seat_type;
        double seatFare = 0;
        double farePerKm = 0.12; // Fare per kilometer for American Airlines in dollars
        double travelDuration = (double) distance / 800;
        switch (seatType) {
            case "economy":
                seatFare = 250; // Fare for economy class in dollars
                break;
            case "business":
                seatFare = 500; // Fare for business class in dollars
                break;
        }
        double ticketFare = (distance * farePerKm) + (seatFare * travelDuration);
        ticketFare *= seats;
        model.addAttribute("ticketFare", ticketFare);

        PassengerDetails passDet = new PassengerDetails(firstName, lastName, journey_date, source, destination,
                seat_type, seats, payment_mode);

        List<Schedule> sch = new ArrayList<>();
        List<Schedule> dst = new ArrayList<>();
        List<Schedule> li = new ArrayList<>();
        sch = (List<Schedule>) scheduleRepo.findBysource(source);
        dst = (List<Schedule>) scheduleRepo.findBydestination(destination);
        li.addAll(sch);
        li.addAll(dst);
        Set<Schedule> s = new HashSet<Schedule>(li);
        List<Schedule> result = new ArrayList<>();
        for (Schedule sd : s) {
            if (sd.getSource().equals(source) && sd.getDestination().equals(destination))
                result.add(sd);
        }
        model.addAttribute("sche", result);
        passRepo.save(passDet);
        return "selectSchedule";

    }

}