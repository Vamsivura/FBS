package com.vamsi.controller.administrator;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.vamsi.entities.administrator.AdministratorCredentials;
import com.vamsi.entities.administrator.AdministratorProfile;
import com.vamsi.repository.AdministratorCredentialsRepository;
import com.vamsi.repository.AdministratorProfileRepository;

@Controller
public class AdministratorController {
	@Autowired
	AdministratorProfileRepository aProfileRepo;

	@Autowired
	AdministratorCredentialsRepository aCredentialsRepo;

	@GetMapping(path = "/administrator")
	public String administratorRegister(@RequestParam("userId") Integer id, @RequestParam("email") String emailId,
			@RequestParam("firstName") String firstName, @RequestParam("lastName") String lastName,
			@RequestParam("dob") String DOB, @RequestParam("age") Integer age, @RequestParam("gender") String gender,
			@RequestParam("address") String address, @RequestParam("phoneNumber") Long phoneNumber,
			@RequestParam("password") String password) {

		AdministratorProfile adminProfile = new AdministratorProfile(id, firstName, lastName, DOB, age, gender, address,
				phoneNumber, emailId);
		AdministratorCredentials adminCred = new AdministratorCredentials("administrator",id, password);

		// save administrator details
		aProfileRepo.save(adminProfile);
		aCredentialsRepo.save(adminCred);
		return "success";
	}

	@GetMapping("/administrator/all")
	@ResponseBody
	public ArrayList<AdministratorProfile> getAllAdministrators() {
		return (ArrayList<AdministratorProfile>) aProfileRepo.findAll();
	}
	@RequestMapping(path = "/administratorCredentials/all", method = RequestMethod.GET)
	@ResponseBody
	public ArrayList<AdministratorCredentials> getAllAdminsitratorCredentials() {
		return (ArrayList<AdministratorCredentials>) aCredentialsRepo.findAll();
	}
	
}
