package com.vamsi.controller.administrator;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.vamsi.entities.backend.Schedule;
import com.vamsi.repository.ScheduleRepository;

@Controller
public class ScheduleController {
	
	@Autowired
	ScheduleRepository scheduleRepo;
	
	//Add & Modify
	@GetMapping(path="/insertSchedule")
	public String insertSchedule(@RequestParam("schedule_Id") Integer schedule_Id,
			@RequestParam("flight_name")  String flight_name,
			@RequestParam("source") String source,
			@RequestParam("destination") String destination,
			@RequestParam("depatureDate") String depatureDate,
			@RequestParam("depatureTime") String depatureTime
			) {
		Schedule schedule=new Schedule(schedule_Id,flight_name, source, destination, depatureDate,depatureTime);
		scheduleRepo.save(schedule);	
		return "success";
	}
	
	//view
		@GetMapping("/viewAllSchedules")
		public String viewEmployees(Model model) {
			List<Schedule> schedule = (ArrayList<Schedule>) scheduleRepo.findAll();
			model.addAttribute("schedule", schedule);
			return "allSchedules";
		}
	
	//delete
	@GetMapping("/deleteSchedule")
	public String deleteSchedule(@RequestParam("schedule_Id")  Integer schedule_Id) {
		scheduleRepo.deleteById(schedule_Id);
		return "success";
	}

}
/*

	@Autowired
	CustomerFlightRepository repo;

	@RequestMapping(path = "/schedule", method = RequestMethod.GET)
	public String schedule(@RequestParam("pnr") Integer pnr, Model model) {
		Optional<CustomerFlightReservation> optional = repo.findById(pnr);
		CustomerFlightReservation cfr = (optional.isPresent()) ? optional.get() : null;
		model.addAttribute("id",cfr.getUser_id());
		model.addAttribute("type",cfr.getReservationType());
		model.addAttribute("source",cfr.getSource());
		model.addAttribute("dest",cfr.getDestination());
		return "schedulePage";
	}
	*/

