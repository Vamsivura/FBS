package com.vamsi.repository;

import org.springframework.data.repository.CrudRepository;

import com.vamsi.entities.backend.Flight;

public interface FlightRepository extends CrudRepository<Flight, String> {

}
