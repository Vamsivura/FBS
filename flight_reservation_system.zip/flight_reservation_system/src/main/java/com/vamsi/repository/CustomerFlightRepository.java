package com.vamsi.repository;

import org.springframework.data.repository.CrudRepository;

import com.vamsi.entities.customers.CustomerFlightReservation;

public interface CustomerFlightRepository extends CrudRepository<CustomerFlightReservation, Integer> {

}
