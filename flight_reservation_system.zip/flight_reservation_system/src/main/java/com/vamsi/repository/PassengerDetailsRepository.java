package com.vamsi.repository;

import org.springframework.data.repository.CrudRepository;

import com.vamsi.entities.customers.PassengerDetails;

public interface  PassengerDetailsRepository extends CrudRepository<PassengerDetails, Integer> {

}
