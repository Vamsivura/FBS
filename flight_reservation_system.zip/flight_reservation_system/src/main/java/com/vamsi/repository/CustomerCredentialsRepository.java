package com.vamsi.repository;

import org.springframework.data.repository.CrudRepository;

import com.vamsi.entities.customers.CustomerCredentials;

public interface CustomerCredentialsRepository extends CrudRepository<CustomerCredentials, Integer> {

}
