package com.vamsi.repository;

import org.springframework.data.repository.CrudRepository;

import com.vamsi.entities.customers.CustomerProfile;

public interface CustomerProfileRepository extends CrudRepository<CustomerProfile, Integer> {

}
