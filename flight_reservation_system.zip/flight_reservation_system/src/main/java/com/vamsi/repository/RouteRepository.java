package com.vamsi.repository;

import org.springframework.data.repository.CrudRepository;

import com.vamsi.entities.backend.Route;

public interface RouteRepository extends CrudRepository<Route, Integer> {

}
