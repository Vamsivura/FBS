package com.vamsi.repository;

import org.springframework.data.repository.CrudRepository;

import com.vamsi.entities.backend.GeoLocation;

public interface GeoLocationRepository extends CrudRepository<GeoLocation, String> {

}
