package com.vamsi.repository;

import org.springframework.data.repository.CrudRepository;

import com.vamsi.entities.administrator.AdministratorCredentials;

public interface AdministratorCredentialsRepository extends CrudRepository<AdministratorCredentials, Integer> {

}
