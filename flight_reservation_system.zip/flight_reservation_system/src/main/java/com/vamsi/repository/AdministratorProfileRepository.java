package com.vamsi.repository;

import org.springframework.data.repository.CrudRepository;

import com.vamsi.entities.administrator.AdministratorProfile;

public interface AdministratorProfileRepository extends CrudRepository<AdministratorProfile, Integer> {

}
